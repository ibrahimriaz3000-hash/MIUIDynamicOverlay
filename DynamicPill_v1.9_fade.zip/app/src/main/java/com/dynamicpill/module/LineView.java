package com.dynamicpill.module;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** iOS style thin rounded "grabber" line: translucent glass look + smooth fade in/out. */
public class LineView extends View {
    private static final long FADE_MS = 300;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private int baseAlpha = 180;   // 0..255 from the Opacity slider
    private float fade = 0f;       // 0 = fully transparent, 1 = fully shown
    private boolean shown = false;
    private ValueAnimator anim;
    private int tint = 0x00FFFFFF; // RGB only (white normally, green charging, yellow power saving)

    public LineView(Context c) {
        super(c);
        fill.setStyle(Paint.Style.FILL);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(Math.max(1f, getResources().getDisplayMetrics().density * 0.6f));
        setVisibility(View.GONE);
    }

    /** 0..100 percent. */
    public void setLineAlpha(int percent) {
        int a = Math.round(255f * Math.max(0, Math.min(100, percent)) / 100f);
        if (baseAlpha != a) {
            baseAlpha = a;
            invalidate();
        }
    }

    /** Line colour (RGB, alpha ignored). */
    public void setTint(int color) {
        int t = color & 0x00FFFFFF;
        if (tint != t) {
            tint = t;
            invalidate();
        }
    }

    /** Show or hide with a smooth transparent fade. Call instead of setVisibility. */
    public void setShown(boolean on) {
        if (on == shown) return;
        shown = on;
        if (anim != null) anim.cancel();
        if (on) setVisibility(View.VISIBLE);
        anim = ValueAnimator.ofFloat(fade, on ? 1f : 0f);
        anim.setDuration(FADE_MS);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                fade = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled = false;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (!cancelled && !shown) setVisibility(View.GONE);
            }
        });
        anim.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float r = h / 2f;

        // glass body: brighter on top, more see-through at the bottom
        int top = Math.round(baseAlpha * fade);
        int bottom = Math.round(baseAlpha * fade * 0.55f);
        fill.setShader(new LinearGradient(0, 0, 0, h,
                (top << 24) | tint, (bottom << 24) | tint, Shader.TileMode.CLAMP));
        rect.set(0, 0, w, h);
        canvas.drawRoundRect(rect, r, r, fill);

        // thin light edge so it reads as glass
        edge.setColor(((int) (baseAlpha * fade * 0.5f) << 24) | tint);
        float s = edge.getStrokeWidth() / 2f;
        rect.set(s, s, w - s, h - s);
        canvas.drawRoundRect(rect, Math.max(0f, r - s), Math.max(0f, r - s), edge);
    }
}
